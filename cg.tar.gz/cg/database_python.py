#!/user/bin/python

#import mysql.connector
import MySQLdb


string1= raw_input("enter database name: ")
db=MySQLdb.connect(host="localhost",user="root",passwd="root",db=string1)

cursor = db.cursor()

####################cretae table############################################

cursor.execute("show tables")

for row in cursor.fetchall():
	print " ",row[0]
###################select * from ########################################
string2=raw_input("use table name :")
cursor.execute("select * from "+string2)

for row1 in cursor.fetchall():
	print "f_name ",row1[0]



####################Insert value#########################################
print "**** Change the value in above Table ****"
string3=raw_input("insert value :")
sql1=string3
try:
	cursor.execute(sql1)
	db.commit()
except:
	db.rollback()

######################################################################
db.close()


