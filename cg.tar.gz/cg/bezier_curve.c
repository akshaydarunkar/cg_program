 
/*  bezsurf.c
 *  This program renders a lighted, filled Bezier surface,
 *  using two-dimensional evaluators.
 */
#include <stdlib.h>
#include <GL/glut.h>
#include<stdio.h>

#define ROT_INC		0.1

static GLfloat g_rotate = 0;
static GLfloat g_rotInc = ROT_INC; /* degree increment for rotation animation */

GLfloat ctrlpoints[4][4][3] =
{
    {
        {-1.5f,-1.5f,3.0f},
        {-0.5f,-1.5f,2.5f},
        {0.5f,-1.5f,2.5f}, 
        {1.0f,-1.5f,3.0f}
  },
    {
        {-1.5f,-0.5f,1.0f},
        {-0.5f,-0.5f,3.0f},
        {0.5f, -0.5f, 0.0f},
        {1.0f, -0.5,-1.0f}
    },
    {
        {-1.5f, 0.5f, 0.0f},
        {-0.5f, 0.5f, 0.0f},
        {0.5f, 0.5f, 0.0f},
        {1.0f, 0.5f, 0.0f}
   },
    {
        {-1.5f, 1.5f, -3.0f},
        {-0.5f, 1.5f, -2.0f},
        {0.5f, 1.5f, -2.0f},
        {0.5f, 1.5f, -3.0f}}
};

/*
GLfloat ctrlpoints[4][4][3] =
    {
   {
     {-1.5, -1.5, 4.0}, {-0.5, -1.5, 2.0}, 
    {0.5, -1.5, -1.0}, {1.5, -1.5, 2.0}}, 
   {{-1.5, -0.5, 1.0}, {-0.5, -0.5, 3.0}, 
    {0.5, -0.5, 0.0}, {1.5, -0.5, -1.0}}, 
   {{-1.5, 0.5, 4.0}, {-0.5, 0.5, 0.0}, 
    {0.5, 0.5, 3.0}, {1.5, 0.5, 4.0}}, 
   {{-1.5, 1.5, -2.0}, {-0.5, 1.5, -2.0}, 
    {0.5, 1.5, 0.0}, {1.5, 1.5, -1.0}}
};*/

void myMouse(int btn, int state, int x, int y)
{   

    if(btn==GLUT_LEFT_BUTTON && state == GLUT_DOWN) g_rotInc += ROT_INC;
	if(btn==GLUT_MIDDLE_BUTTON && state == GLUT_DOWN) g_rotInc = ROT_INC;
	/* if(btn==GLUT_RIGHT_BUTTON && state == GLUT_DOWN) g_rotInc -= ROT_INC;
	*/
	/* force redisplay */
	glutPostRedisplay();
}   

void initlights(void)
{
    GLfloat ambient[] =
    {0.2, 0.2, 0.2, 1.0};
    GLfloat position[] =
    {0.0, 0.0, 2.0, 1.0};
    GLfloat mat_diffuse[] =
    {0.6, 0.6, 0.6, 1.0};
    GLfloat mat_specular[] =
    {1.0, 1.0, 1.0, 1.0};
    GLfloat mat_shininess[] =
    {50.0};

    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);

    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT0, GL_POSITION, position);

    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
}

void 
display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glPushMatrix();
    glRotatef(120.0, 1.0, 1.0, 1.0);
    glEvalMesh2(GL_FILL, 0, 22, 0, 22);
    glPopMatrix();

   
 glFlush();
}


void myIdleFunc(void) {

	g_rotate += g_rotInc;

	/* force glut to call the display function */
	glutPostRedisplay();
}
void myKey(unsigned char k, int x, int y)
{
	switch (k) {
		case 'q':
		case 'Q':	exit(0);
		break;

                case 'l':
                      glRotatef(30.0,0.0f,1.0f,0.0f);
                      break;
                case 'r':
                     glRotatef(-30.0,0.0f,1.0f,0.0f);
                      break;
                
                 case 'u':
                     glRotatef(120.0,0.0f,1.0f,0.0f);
                      break;
                  
                 case 'd':
                     glRotatef(-120.0,0.0f,1.0f,0.0f);
                      break;
                
	default:
		printf("Unknown keyboard command \n", k);
		break;
	}
}


void 
myinit(void)
{
    glClearColor(0.0, 0.0, 0.0, 1.0);
    glEnable(GL_DEPTH_TEST);
    glMap2f(GL_MAP2_VERTEX_3, 0, 1, 3, 4,
        0, 1, 12, 4, &ctrlpoints[0][0][0]);
    glEnable(GL_MAP2_VERTEX_3);
   // glEnable(GL_AUTO_NORMAL);
    //glEnable(GL_NORMALIZE);
    glMapGrid2f(20, 0.0, 1.0, 20, 0.0, 1.0);
 //   initlights();       /* for lighted version only */
}

void 
myReshape(int w, int h)
{
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    if (w <= h)
        glOrtho(-4.0, 4.0, -4.0 * (GLfloat) h / (GLfloat) w,
            4.0 * (GLfloat) h / (GLfloat) w, -4.0, 4.0);
    else
        glOrtho(-4.0 * (GLfloat) w / (GLfloat) h,
            4.0 * (GLfloat) w / (GLfloat) h, -4.0, 4.0, -4.0, 4.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

int 
main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
    glutCreateWindow(argv[0]);
    myinit();
    glutReshapeFunc(myReshape);
     	glutIdleFunc(myIdleFunc);
        	glutMouseFunc(myMouse);
    glutDisplayFunc(display);
    glutKeyboardFunc(myKey);
    glutMainLoop();
    return 0;             /* ANSI C requires main to return int. */
}
