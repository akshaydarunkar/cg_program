"""
data=[]
data1=[]
n=int(raw_input("enter how many N elemnt:"))
for i in  range (n):
	x=raw_input("enter N no:")
	data.append(x)

m=int(raw_input("enter how many M elemnt:"))
for i in range (m):
	y=raw_input("enter M no:")
	data1.append(y)

print sorted(data)
print  sorted(data1)
data.extend(data1)
print data
"""
def example(str1):
	str2=[]
	str3=[]
	for i in str1:
		str2.append(i[::-1])
	return " ".join(str2)
		
	
string="this is my string"

str1=string.split(" ")
print string
d=[]
print example(str1)

