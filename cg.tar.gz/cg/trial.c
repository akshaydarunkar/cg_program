#include <stdio.h> 
#include <GL/glut.h>
#include <stdlib.h>
#include <time.h>

void display(void) 
{ 
	int i;
	glClear( GL_COLOR_BUFFER_BIT);  
	glBegin(GL_POINTS);
	glColor3f(1.0, 1.0, 1.0);
	srand((unsigned int)time(NULL));
	float a = 10.0,b=10.0;
	for (i=0;i<7500;i++)
	{
     		float g=((float)rand()/(float)(RAND_MAX)) * a;
     		float s=((float)rand()/(float)(RAND_MAX)) * a;

     		glVertex2f(g,s);
	}

	glEnd(); 
	glFlush(); 

}

int main(int argc, char **argv) 
{ 
	glutInit(&argc, argv); 
 	glutInitDisplayMode ( GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);

 	glutInitWindowPosition(100,100); 
	glutInitWindowSize(300,300); 
 	glutCreateWindow ("akshay");

 	glClearColor(0.0, 0.0, 0.0, 0.0);         // black background 
 	glMatrixMode(GL_PROJECTION);              // setup viewing projection 
 	glLoadIdentity();                           // start with identity matrix 
 	glOrtho(0.0, 10.0, 0.0, 10.0, -1.0, 1.0);   // setup a 10x10x2 viewing world

 	glutDisplayFunc(display); 
 	glutMainLoop();

 return 0; 
}
