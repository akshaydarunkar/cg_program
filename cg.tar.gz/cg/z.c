#include<stdlib.h>
#ifdef __APPLE__
#include<openGL/openGL.h>
#include<GLUT/glut.h>
#else
#include<GL/glut.h>
#endif


void drawRing(GLfloat px,GLfloat py,GLfloat pz,GLfloat &rotation)
{
    glPushMatrix();
    glColor3ub(0,0,255);
    glTranslatef(px,py,pz);
    glRotatef(rotation,0.0f, 1.0f, 0.0f);
    glutSolidTorus(5.0, 30.0, 50, 50);

    rotation+= -1.0f;

    if(rotation > 360.0f)
    {
        rotation = 0.0f;
    }
    glPopMatrix();
}

int main(int argc,char** argv)
{
    glutInit(&argc,argv);

    glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGB|GLUT_DEPTH);

    glutInitWindowSize(100,100);

    glutCreateWindow("Sun");

    initRendering();

    glutDisplayFunc(drawRing);

    glutFullScreen();

    glutMainLoop();

    return(0);
}
