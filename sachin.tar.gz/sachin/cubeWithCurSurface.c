#include<GL/glut.h>
#include<math.h>
#include<stdio.h>
 
void display();
void specialKeys();

float points1[1000][3];
float points2[1000][3];

double rotate_y=0; 
double rotate_x=0;
double rotate_z=0;

float cal_val(float p1,float p2,float p3,float lambda)
{
  return(p1*pow((1-lambda),2) + 2*(1-lambda)*lambda*p2 + (pow(lambda,2))*p3);
}

void find_points(float a[3],float b[3],float c[3],float point[1000][3]){
  float lambda = 0.01, step = 0.005;
  int i;
  for(i=0;i<=1000;i++){
    if(lambda>1)
      break;
    point[i][0] = cal_val(a[0],b[0],c[0],lambda);
    point[i][1] = cal_val(a[1],b[1],c[1],lambda);
    point[i][2] = cal_val(a[2],b[2],c[2],lambda);
    printf("points = [%f %f %f]\n",point[i][0],point[i][1],point[i][2]);
    lambda += step;
  }

}

void display(){
  
  float p11[3]={0.3,0.3,0.3},p12[3]={0.3,0.5,0.0},p13[3]={0.3,0.3,-0.3};
  float p21[3]={-0.3,0.3,0.3},p22[3]={-0.3,0.5,0.0},p23[3]={-0.3,0.3,-0.3};


  find_points(p11,p12,p13,points1);
  find_points(p21,p22,p23,points2);
  glClearColor(1.0,1.0,1.0,0.0);
  glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

  glLoadIdentity();
  
  glMatrixMode(GL_PROJECTION);
  gluPerspective(30.0, 1.0, 1.0, 10.0);
    //glMatrixMode(GL_MODELVIEW);
  gluLookAt( 0.0, 0.0, 5.0,  0.0, 0.0, 0.0,  0.0, 1.0, 0.0);

  glTranslatef(0.0, 0.0, 1.0);
  glRotatef(25, 1.0, 0.0, 0.0);
  glRotatef(10, 0.0, 0.0, 1.0);
 
  glRotatef( rotate_x, 1.0, 0.0, 0.0 );
  glRotatef( rotate_y, 0.0, 1.0, 0.0 );
  glRotatef( rotate_z, 0.0, 0.0, 1.0 );


  glColor3f(0,1,0);
  glBegin(GL_LINE);
  for(int i=0;i<999;i++){
    glVertex3f(points1[i][0],points1[i][1],points1[i][2]);
  }
  glEnd();  
  glFlush();  
  
  glBegin(GL_LINE);
  for(int i=0;i<999;i++){
    glVertex3f(points2[i][0],points2[i][1],points2[i][2]);
  }
  glEnd();    
  glFlush();

  for(int i=0;i<1000;i++){
    glBegin(GL_LINES);
    glVertex3f(points1[i][0],points1[i][1],points1[i][2]);
    glVertex3f(points2[i][0],points2[i][1],points2[i][2]);
    glEnd();    
  }
  glFlush();

  glColor3f(1,0,0);
  glBegin(GL_LINES);
  glVertex3f(0.3,0.3,0.3);
  glVertex3f(0.3,0.3,-0.3);
  glEnd();
  
  
  glBegin(GL_LINES);
  glVertex3f(0.3,-0.3,0.3);
  glVertex3f(0.3,-0.3,-0.3);
  glEnd();

 
  glBegin(GL_LINES);
  glVertex3f(-0.3,0.3,0.3);
  glVertex3f(-0.3,0.3,-0.3);
  glEnd();

  
  
  glBegin(GL_LINES);
  glVertex3f(-0.3,0.3,0.3);
  glVertex3f(0.3,0.3,0.3);
  glEnd();

  
  glBegin(GL_LINES);
  glVertex3f(-0.3,-0.3,-0.3);
  glVertex3f(-0.3,0.3,-0.3);
  glEnd();

  
  glBegin(GL_LINES);
  glVertex3f(0.3,0.3,-0.3);
  glVertex3f(0.3,-0.3,-0.3);
  glEnd();

  
  glBegin(GL_LINES);
  glVertex3f(-0.3,-0.3,-0.3);
  glVertex3f(0.3,-0.3,-0.3);
  glEnd();

  
  glBegin(GL_LINES);
  glVertex3f(-0.3,-0.3,-0.3);
  glVertex3f(-0.3,-0.3,0.3);
  glEnd();

  
  glBegin(GL_LINES);
  glVertex3f(-0.3,0.3,0.3);
  glVertex3f(-0.3,-0.3,0.3);
  glEnd();

  
  glBegin(GL_LINES);
  glVertex3f(0.3,0.3,-0.3);
  glVertex3f(-0.3,0.3,-0.3);
  glEnd();


  glBegin(GL_LINES);
  glVertex3f(-0.3,-0.3,0.3);
  glVertex3f(0.3,-0.3,0.3);
  glEnd();

  glBegin(GL_LINES);
  glVertex3f(0.3,0.3,0.3);
  glVertex3f(0.3,-0.3,0.3);
  glEnd();

  glFlush();
  glutSwapBuffers();
 
}
 
void specialKeys( int key, int x, int y ) {
 
  if (key == GLUT_KEY_RIGHT)
    rotate_y += 5;
 
  else if (key == GLUT_KEY_LEFT)
    rotate_y -= 5;
 
  else if (key == GLUT_KEY_UP)
    rotate_x += 5;
 
  else if (key == GLUT_KEY_DOWN)
    rotate_x -= 5;
 
  glutPostRedisplay();
 
}
 
int main(int argc, char* argv[]){
 
  glutInit(&argc,argv);
 
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
  glutInitWindowSize (1000, 1000);
  glutInitWindowPosition (100, 100);
  glutCreateWindow("Awesome Cube");
 
  glEnable(GL_DEPTH_TEST);
 
  glutDisplayFunc(display);
  glutSpecialFunc(specialKeys);
 
  glutMainLoop();
 
  return 0;
 
}
