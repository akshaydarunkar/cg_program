#include<GL/glut.h>
#include<math.h>
#include<stdio.h>
 
float points1[1000][3];
float points2[1000][3];

double rotate_y=0; 
double rotate_x=0;
double rotate_z=0;

void display();
void specialKeys();

void display(){

  glClearColor(0.0,0.0,0.0,1.0);
  glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

  glLoadIdentity();
  
  glMatrixMode(GL_PROJECTION);
  gluPerspective(30.0, 1.0, 1.0, 10.0);
    //glMatrixMode(GL_MODELVIEW);
  gluLookAt( 0.0, 0.0, 5.0,  0.0, 0.0, 0.0,  0.0, 1.0, 0.0);
//-------------------------------------------------------------------------
/*	 glColor3f(0,1,1);
        glBegin(GL_LINE_STRIP);
        glVertex2f(0.0, -1.3);
        glVertex2f(0.0,1.3);
        glEnd();


	 glColor3f(0,1,1);
        glBegin(GL_LINE_STRIP);
        glVertex2f(-1.3, 0.0);
        glVertex2f(1.3,0.0);
        glEnd();
*/	

//------------------------------------------------------------------------------

  glTranslatef(0.0, 0.0, 1.0);
  glRotatef(25, 1.0, 0.0, 0.0);
  glRotatef(10, 0.0, 0.0, 1.0);
 
  glRotatef( rotate_x, 1.0, 0.0, 0.0 );
  glRotatef( rotate_y, 0.0, 1.0, 0.0 );
  glRotatef( rotate_z, 0.0, 0.0, 1.0 );


  glColor3f(0,1,1);
  glBegin(GL_LINE);
  for(int i=0;i<999;i++){
    glVertex3f(points1[i][0],points1[i][1],points1[i][2]);
  }
  glEnd();  
  glFlush();  
  
  glBegin(GL_LINE);
  for(int i=0;i<999;i++){
    glVertex3f(points2[i][0],points2[i][1],points2[i][2]);
  }
  glEnd();    
  glFlush();

  for(int i=0;i<1000;i++){
    glBegin(GL_LINES);
    glVertex3f(points1[i][0],points1[i][1],points1[i][2]);
    glVertex3f(points2[i][0],points2[i][1],points2[i][2]);
    glEnd();    
  }
  glFlush();

  glColor3f(1,1,0);
  glBegin(GL_LINES);
  glVertex3f(0.3,0.3,0.3);
  glVertex3f(0.3,0.3,-0.3);
  glEnd();
  
  
 /* glBegin(GL_LINES);
  glVertex3f(0.3,-0.3,0.3);
  glVertex3f(0.3,-0.3,-0.3);
  glEnd();

 */
  glBegin(GL_LINES);
  glVertex3f(-0.3,0.3,0.3);
  glVertex3f(-0.3,0.3,-0.3);
  glEnd();

  
  
  glBegin(GL_LINES);
  glVertex3f(-0.3,0.3,0.3);
  glVertex3f(0.3,0.3,0.3);
  glEnd();

  
  glBegin(GL_LINES);
  glVertex3f(-0.3,-0.3,-0.3);
  glVertex3f(-0.3,0.3,-0.3);
  glEnd();

  
  glBegin(GL_LINES);
  glVertex3f(0.3,0.3,-0.3);
  glVertex3f(0.3,-0.3,-0.3);
  glEnd();

  
  glBegin(GL_LINES);
  glVertex3f(-0.3,-0.3,-0.3);
  glVertex3f(0.3,-0.3,-0.3);
  glEnd();

  
  glBegin(GL_LINES);
  glVertex3f(-0.3,-0.3,-0.3);
  glVertex3f(-0.3,-0.3,0.3);
  glEnd();

  
  glBegin(GL_LINES);
  glVertex3f(-0.3,0.3,0.3);
  glVertex3f(-0.3,-0.3,0.3);
  glEnd();

  
  glBegin(GL_LINES);
  glVertex3f(0.3,0.3,-0.3);
  glVertex3f(-0.3,0.3,-0.3);
  glEnd();


  glBegin(GL_LINES);
  glVertex3f(-0.3,-0.3,0.3);
  glVertex3f(0.3,-0.3,0.3);
  glEnd();

  glBegin(GL_LINES);
  glVertex3f(0.3,0.3,0.3);
  glVertex3f(0.3,-0.3,0.3);
  glEnd();

  glFlush();
  glutSwapBuffers();
 
}
 
void specialKeys( int key, int x, int y ) {
 
  if (key == GLUT_KEY_RIGHT)
    rotate_y += 1;
 
  else if (key == GLUT_KEY_LEFT)
    rotate_y -= 1;
 
  else if (key == GLUT_KEY_UP)
    rotate_x += 1;
 
  else if (key == GLUT_KEY_DOWN)
    rotate_x -= 1;
 
  glutPostRedisplay();
 
}
 
int main(int argc, char* argv[]){
 
  glutInit(&argc,argv);
 
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
  glutInitWindowSize (1000, 1000);
  glutInitWindowPosition (100, 100);
  glutCreateWindow(" CG object");
 
  glEnable(GL_DEPTH_TEST);
 
  glutDisplayFunc(display);
  //glutSpecialFunc(specialKeys);
 
  glutMainLoop();
 
  return 0;
 
}
