#include<GL/glut.h>
#include<math.h>
#include<stdio.h>

double rotate_x=0;
double rotate_y=0;
double rotate_z=0;

float pt1[2000][3];
float pt2[2000][3];


float cal_val(float p1,float p2,float p3,float lambda)
{
	return(p1*pow((1-lambda),2) + 2*(1-lambda)*lambda*p2 + (pow(lambda,2))*p3);
}

void find_point(float a[3],float b[3],float c[3],float point[1000][3])
{
	float lambda=0.01,step=0.005;
	int i;
	for(i=0;i<=500;i++)
	{
		if(lambda>1)
			break;
		point[i][0] = cal_val(a[0],b[0],c[0],lambda);
		point[i][1] = cal_val(a[1],b[1],c[1],lambda);
		point[i][2] = cal_val(a[2],b[2],c[2],lambda);
		printf("points= [%f %f %f]\n",point[i][0],point[i][1],point[i][2]);
		lambda +=step;
	}
}

void display()
{

	float p11[3]={0.4,0.4,0.4},
	      p12[3]={0.4,0.7,0.0},
	      p13[3]={0.4,0.4,-0.4};

	float p21[3]={-0.4,0.4,0.4},
	      p22[3]={-0.4,0.7,0.0},
	      p23[3]={-0.4,0.4,-0.4};

	find_point(p11,p12,p13,pt1);
	find_point(p21,p22,p23,pt2);

	glClearColor(1.0,1.0,1.0,0.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	glLoadIdentity();
	
	glMatrixMode(GL_PROJECTION);
	gluPerspective(30.0,1.0,1.0,20.0);
	
	gluLookAt( 0.0, 0.0, 8.0,  0.0, 0.0, 0.0,  0.0, 3.0, 0.0);

 	 glTranslatef(0.0, 0.0, 3.0);
 	 glRotatef(25, 1.0, 0.0, 0.0);
       	glRotatef(30, 0.0, 0.0, 1.0);
 
  	glRotatef( rotate_x, 1.0, 0.0, 0.0 );
  	glRotatef( rotate_y, 0.0, 1.0, 0.0 );
  	glRotatef( rotate_z, 0.0, 0.0, 1.0 );


  	glColor3f(0,1,2);
  	glBegin(GL_LINE);
  	for(int i=0;i<999;i++)
	{
    		glVertex3f(pt1[i][0],pt1[i][1],pt1[i][2]);
  	}
  		glEnd();  
  		glFlush();  
  
 		 glBegin(GL_LINE);
  		for(int i=0;i<999;i++)
		{
    			glVertex3f(pt2[i][0],pt2[i][1],pt2[i][2]);
  		}
  			glEnd();    
  			glFlush();

  for(int i=0;i<1000;i++){
    glBegin(GL_LINES);
    glVertex3f(pt1[i][0],pt1[i][1],pt1[i][2]);
    glVertex3f(pt2[i][0],pt2[i][1],pt2[i][2]);
    glEnd();    
  }
  glFlush();

  glutSwapBuffers();
 
}

void specialKeys(int key,int x,int y)	
{
	if(key == GLUT_KEY_RIGHT)
		rotate_y +=2;
	else if (key == GLUT_KEY_LEFT)
		rotate_y -=2;
	else if (key == GLUT_KEY_UP)
		rotate_x +=2;
	else if (key == GLUT_KEY_DOWN)
		rotate_x -=2;

	glutPostRedisplay();

}		

int main(int argc,char* argv[])
{

	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(1500,1500);
	glutInitWindowPosition(100,100);
	glutCreateWindow("Cube");
	glEnable(GL_DEPTH_TEST);
	glutDisplayFunc(display);
	glutSpecialFunc(specialKeys);
        glutDisplayFunc(display);
	glutMainLoop();
	return 0;
}
