#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <GL/glut.h>

#define N 4 // number of control points
#define D 2 // number of dimensions
#define T 50 
int connection=0;

static GLfloat ctrlPoints[N][3] = {{100, 100, 0}, {200, 350, 0}, {400,300, 0}, {480,100,0}};
GLUnurbsObj *theNurb;

int typeMode = 1;	 

// window size
int ww = 1000;
int wh = 800;

// remember the moving control name
int MOVENAME = -1;

// set up pick radius for detecting movement of a control point
int pickRadius = 50;


void display2DControlPolyline()
{
	glLineWidth(2.0);

	glColor3f(1.0f, 0.0f, 220.0f);
  
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < N; i++)
	{
      glVertex2i(ctrlPoints[i][0],ctrlPoints[i][1]);
	}
    glEnd();
    glFlush();
}

void display2DControlPoints()
{
	glPointSize(3.0);
	glColor3f(0.0f, 1.0f, 0.0f);

	glBegin(GL_POINTS);
	for (int i = 0; i < N; i++)
	{
      glVertex2i(ctrlPoints[i][0],ctrlPoints[i][1]);
	}
    glEnd();
    glFlush();
}


void bezierOpenGL()
{
	//printf("\nEvaluating Bezier Form using OpenGL...\n");

	// Set up Bezier map

   glMap1f(GL_MAP1_VERTEX_3, 0.0, 1.0, 3, 4, &ctrlPoints[0][0]);
   glEnable(GL_MAP1_VERTEX_3);

	glLineWidth(4.0);
	glColor3f(1.0f, 1.0f, 1.0f);
  
	glBegin(GL_LINE_STRIP);

	
	for(int i=0;i<=MOVENAME;i++)
		glEvalCoord1f((GLfloat)i/(GLfloat)MOVENAME);

	glEnd();
    glFlush();
}
void keyboard(unsigned char key,int x,int y)
{
	if(key=='0')
        exit(0);
    
   
	switch(key)
	{
		case 27:
			exit(0);
			break;
		case 'l':
			MOVENAME++;
			break;
		case '-':
			MOVENAME--;
			break;
	}
	if(MOVENAME<0)
		MOVENAME=0;
	glutPostRedisplay();
}



void bSpline()
{
	//printf("\nCalculating uniform B-Spline Form...\n");

	glLineWidth(4.0);
	glColor3f(1.0f, 1.0f, 1.0f);

	GLfloat fu[N];
  
	glBegin(GL_LINE_STRIP);

	for (int uInt = 0; uInt <= T; uInt++)
	{
		GLfloat u = uInt/(GLfloat)T;
		GLfloat u2 = u*u;
		GLfloat u3 = u2*u;
		fu[0] = -u3/6.0 + u2/2.0 -u/2.0 + 1.0/6.0;
		fu[1] = u3/2.0 - u2 + 2.0/3.0;
		fu[2] = -u3/2.0 + u2/2.0 + u/2.0 + 1.0/6.0;
		fu[3] = u3/6.0;

		GLfloat x = 0.0;
		GLfloat y = 0.0;
	
		for (int i = 0; i < N; i++)
		{
			x += fu[i]*ctrlPoints[i][0];
			y += fu[i]*ctrlPoints[i][1];
		}
		//printf("x=%g  y=%g\n", x, y);
		glVertex2i(x,y);
	}

	glEnd();
    glFlush();
}

void drawCurve()
{
	switch (typeMode){
		case 1:
			display2DControlPolyline();
			display2DControlPoints();
			break;
		
		case 5:
			bezierOpenGL();
			break;
		case 6:
			bSpline();
			break;
		
		default:
			exit(0);
	}
	
}

void myDisplay()
{
  glClear(GL_COLOR_BUFFER_BIT);
  display2DControlPolyline();
  display2DControlPoints();
  //drawCurve();
  glFlush();
}

void mainMenu(int id)
{
	typeMode = id;
	if (typeMode > 7) exit(0);
	glutPostRedisplay();
}


void init()
{
   glClearColor(0.0, 0.0, 1.0, 0.0);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   gluOrtho2D(0.0, ww, 0.0, wh);
}

// mouse function
void myPick(int button, int state, int xPosition, int yPosition)
{
	// left mouse button down
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
		GLuint newX = xPosition;
		GLuint newY = wh - yPosition;
		//printf("Pick location: x = %d   y = %d\n", newX, newY);

	// determine which control point is picked

	int choiceFound = 0;

	for (int i = 0; i < N && !choiceFound; i++)
	{
		// Use globally defined pickRadius

		if ((abs(ctrlPoints[i][0] - newX) <= pickRadius) &&
		    (abs(ctrlPoints[i][1] - newY) <= pickRadius))
		{
			MOVENAME = i;
			choiceFound = 1;
			//printf("Control point %d was picked.\n",MOVENAME);
		}
	}
	}

	// left mouse button up
	if (button == GLUT_LEFT_BUTTON && state == GLUT_UP) {
		MOVENAME = -1;
	}
	glutPostRedisplay();
}

// mouse motion function
void myMouseMove(int xPosition, int yPosition)
{
	if (MOVENAME > -1)
	{
	 GLuint newX = xPosition;
	 GLuint newY = wh - yPosition;
	 //printf("New control point %d location: x = %d   y = %d\n", MOVENAME, newX, newY);

	 ctrlPoints[MOVENAME][0] = newX;
	 ctrlPoints[MOVENAME][1] = newY;
	
	glutPostRedisplay();
	}
}

void reshape(int w, int h)
{
	glViewport(0, 0, (GLsizei) w, (GLsizei) h);
	ww = w;
	wh = h;
}


int main(int argc, char **argv)
{

   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(ww, wh);
   glutInitWindowPosition(0,0);
   glutCreateWindow("Curve Evaluation");
   glutDisplayFunc(myDisplay);
   glutMouseFunc(myPick);
   glutMotionFunc(myMouseMove);
   glutKeyboardFunc(keyboard);
   glutReshapeFunc(reshape);
   init();

	glutMainLoop();
	return 0;
}
