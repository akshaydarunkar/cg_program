
#include <GL/gl.h>
#include <GL/glx.h>
#include <GL/glext.h>

#include <GL/glut.h>
#include <math.h>
#include<stdio.h>
#include<stdlib.h>
 

float points_part1[250][3];
float points_part3[250][3];
float points_part5[250][3];


float curve_point1[250][250][3];
float curve_point2[250][250][3];
float curve_point3[250][250][3];

double rotate_y=0; 
double rotate_x=0;
double rotate_z=0;

void init()
{
    glClearColor(1.0,1.0,1.0,0.0);
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(0.0,200.0,0.0,150.0);
}

/* points For Curve */

float cal_val_4_point(float p1,float p2,float p3,float p4,float lambda)
{
  return( p1*pow((1-lambda),3) + p2*3*pow((1-lambda),2)*lambda + p3*3*pow(lambda,2)*(1-lambda) + p4*pow(lambda,3));
}

float cal_val_3_point(float p1,float p2,float p3,float lambda)
{
  return(p1*pow((1-lambda),2) + p2*2*(1-lambda)*lambda + p3*pow(lambda,2));
}

void points_for_curve(float a[3],float b[3],float c[3],float d[3],float point[250][3]){
  float lambda = 0.0, step = 0.004;
  int i;
  for(i=0;i<=250;i++){
    if(lambda>1)
      break;
    point[i][0] = cal_val_4_point(a[0],b[0],c[0],d[0],lambda);
    point[i][1] = cal_val_4_point(a[1],b[1],c[1],d[1],lambda);
    point[i][2] = cal_val_4_point(a[2],b[2],c[2],d[2],lambda);
    lambda += step;
  }

}

/* Draw Points */
float plot_curve(float points_arr[250][250][3]){
  int i,j;
  for( j=0;j<=250;j++){
    glBegin(GL_POINTS);
    for( i=0;i<=250;i++){
      glVertex3f(points_arr[j][i][0],points_arr[j][i][1],points_arr[j][i][2]);
    }
    glEnd();    
  }
  
  
}

void define_basic_condition(){

  glClearColor(1.0,1.0,1.0,0.0);
  glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

  glLoadIdentity();
  
  glMatrixMode(GL_PROJECTION);
  gluPerspective(30.0, 1.0, 1.0, 10.0);
  gluLookAt( 0.0, 0.0, 5.0,  0.0, 0.0, 0.0,  0.0, 1.0, 0.0);

  glTranslatef(0.0, 0.0, 1.0);
  glRotatef(25, 1.0, 0.0, 0.0);
  glRotatef(70, 0.0, 0.0, 1.0);
 
  glRotatef( rotate_x, 1.0, 0.0, 0.0 );
  glRotatef( rotate_y, 0.0, 1.0, 0.0 );
  glRotatef( rotate_z, 0.0, 0.0, 1.0 );
}


void display(){
    define_basic_condition();
    int i,j,k;
  float p11[3]={0.0,0.30,-0.1},p12[3]={0.05,0.68,0.0},p13[3]={0.40,0.45,0.0},p14[3]={0.55,0.44,0.1};
  float p31[3]={0.0,0.60,0.0},p32[3]={0.17,0.62,0.0},p33[3]={0.35,0.63,0.0},p34[3]={0.55,0.63,0.0};  
  float p51[3]={0.0,0.55,-0.03},p52[3]={0.17,0.55,-0.04},p53[3]={0.35,0.55,-0.04},p54[3]={0.55,0.55,-0.05};
 
  glColor3f(1.0,0.0,0.0);
/* points calculated for curve */
  points_for_curve(p11,p12,p13,p14,points_part1);// right side curve points
  points_for_curve(p31,p32,p33,p34,points_part3); // left side curve points
  points_for_curve(p51,p52,p53,p54,points_part5);  // middle curve points
/* Draw Curve andJoin Points */ 
  for( i=0;i<=250;i++)
  {
   float lambda = 0.0 ,step = 0.000;
   for(j=0;j<250;j++)
   {
     for(k=0;k<4;k++)
     {
       curve_point1[i][j][k]=cal_val_3_point(points_part1[i][k],points_part1[i][k],points_part3[i][k],lambda);
       curve_point2[i][j][k]=cal_val_3_point(points_part3[i][k],points_part3[i][k],points_part5[i][k],lambda);
       curve_point3[i][j][k]=cal_val_3_point(points_part5[i][k],points_part5[i][k],points_part1[i][k],lambda);
     }
     lambda+=step;
   } 
  } 
 
  plot_curve(curve_point1);
  plot_curve(curve_point2);
  plot_curve(curve_point3);


  
  glFlush();
  glutSwapBuffers();
 
}
 
void specialKeys( int key, int x, int y ) {
 
  if (key == GLUT_KEY_RIGHT)
    rotate_y += 4;
 
  else if (key == GLUT_KEY_LEFT)
    rotate_y -= 4;
 
  else if (key == GLUT_KEY_UP)
    rotate_x += 4;
 
  else if (key == GLUT_KEY_DOWN)
    rotate_x -= 4;
 
  glutPostRedisplay();
 
}
 
int main(int argc, char* argv[]){
 
  glutInit(&argc,argv);
 
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
  glutInitWindowPosition (100, 100);
  glutInitWindowSize (1000, 1000);
  glutCreateWindow("Leg");
 
  glEnable(GL_DEPTH_TEST);
 
  glutDisplayFunc(display);
  glutSpecialFunc(specialKeys);
 
  glutMainLoop();
 
  return 0;
 
}
