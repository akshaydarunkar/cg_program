#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>

void init(void) 
{
   glClearColor (0.0, 0.0, 0.0, 0.0);
   glShadeModel (GL_FLAT);
}

void display(void)
{
   glClear (GL_COLOR_BUFFER_BIT);
   glColor3f (1.0, 1.0, 1.0);
   glLoadIdentity ();             /* clear the matrix */
           /* viewing transformation  */
   gluLookAt (0.0, 0.0, 5.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
   //glScalef (2.0, 2.0, 1.0);      /* modeling transformation */ 
   //glutWireCube (2.0);


 glBegin( GL_LINES);   
    
// RIGHT SIDE
      glColor3f(0.0f, 1.0f, 1.0f);     // SKY bLUE
      glVertex3f(1.25f, 1.25f, 0.0f); 
      glVertex3f(1.0f, -1.0f, 1.0f);
     
      glColor3f(1.0f, 0.0f, 0.0f);     // RED
      glVertex3f(1.0f, -1.0f, 1.0f);
      glVertex3f(1.0f, -1.0f, -1.0f);
 
    
    
      glColor3f(0.0f, 1.0f, 0.0f);     // green
      glVertex3f(0.83f, 0.83f, 0.0f);
      glVertex3f(1.25f, 1.25f, 0.0f);

// left side

       glColor3f(1.75f, 0.0f, 1.0f);     // purple
    
       glVertex3f(-0.83f, 0.83f, 1.68f); // front left side TOP
       glVertex3f(-0.83f, 0.83f, 0.0f); // left side TOP



     glColor3f(1.75f, 0.0f, 1.0f);     // purple
    
     glVertex3f(-0.83f, 0.83f, 1.68f); // front left side TOP
     glVertex3f(-1.0f,-1.0f, 1.0f); // front left side BOTTOM

 // Front
      glColor3f(1.0f,0.0f,0.0f);       // Red
      glVertex3f( 1.0f, -1.0f, 1.0f); // front side   
      glVertex3f(-1.0f,-1.0f, 1.0f); // front left side BOTTOM

      glColor3f(0.0f,0.0f,1.0f);       // Blue
      glVertex3f(-1.0f, -1.0f, -1.0f); // back left side BOTTOM
      glVertex3f(-1.0f,-1.0f, 1.0f); // front left side BOTTOM


      glColor3f(1.0f, 0.0f, 0.0f);     // yellow
    
      glVertex3f(-0.83f, 0.83f, 1.68f); // front left side TOP
      glVertex3f(0.83f, 0.83f, 1.68f);  // front right side TOP



  // BACK

      glColor3f(1.0f, 1.0f, 0.0f);     // yellow
    
      glVertex3f(-0.83f, 0.83f, 0.0f); // left side TOP
      glVertex3f(0.83f, 0.83f, 0.0f);  // right side TOP

      glColor3f(1.0f, 1.0f, 0.0f);     // yellow
      glVertex3f(0.83f, 0.83f, 0.0f);  // right side TOP
      glVertex3f(1.0f, -1.0f, -1.0f);  // right side BOTTOM

      glColor3f(1.0f, 1.0f, 0.0f);     // yellow
      glVertex3f(1.0f, -1.0f, -1.0f); //  right side BOTTOM
      glVertex3f(-1.0f, -1.0f, -1.0f); // left side BOTTOM


     glColor3f(1.0f, 1.0f, 0.0f);     // yellow
     glVertex3f(-0.83f, 0.83f, 0.0f); // left side TOP
     glVertex3f(-1.0f, -1.0f, -1.0f); // left side BOTTOM
   
glEnd();
 
 glBegin(GL_POLYGON);   
      // Right face (x = 1.0f)
      glColor3f(1.0f, 1.0f, 0.0f);     // Magenta
      glVertex3f(1.0f,  1.0f, -1.0f);
      glVertex3f(1.0f,  1.0f,  1.0f);
      glVertex3f(1.0f, -1.0f,  1.0f);
      glVertex3f(1.0f, -1.0f, -1.0f);
   glEnd();  // End of drawing color-cube

 glBegin(GL_POLYGON);   
      //  Left face (x = -1.0f)
      glColor3f(1.0f, 1.0f, 0.0f);     // Blue
      glVertex3f(-1.0f,  1.0f,  1.0f);
      glVertex3f(-1.0f,  1.0f, -1.0f);
      glVertex3f(-1.0f, -1.0f, -1.0f);
      glVertex3f(-1.0f, -1.0f,  1.0f);
 
   glEnd();  // End of drawing color-cube
 
  glBegin(GL_POLYGON);   
     glColor3f(1.0f, 0.5f, 0.0f);     // Orange
      glVertex3f( 1.0f, -1.0f, -1.0f);
      glVertex3f(-1.0f, -1.0f, -1.0f);
      glVertex3f(-1.0f,  1.0f, -1.0f);
      glVertex3f( 1.0f,  1.0f, -1.0f);
   glEnd();  // End of drawing color-cube

  glBegin(GL_POLYGON);   

     glColor3f(0.0f, 1.0f, 0.0f);     // Green
      glVertex3f( 1.0f, 1.0f, -1.0f);
      glVertex3f(-1.0f, 1.0f, -1.0f);
      glVertex3f(-1.0f, 1.0f,  1.0f);
      glVertex3f( 1.0f, 1.0f,  1.0f);

 glEnd();
   
glBegin(GL_POLYGON);   
      // Bottom face (y = -1.0f)
      glColor3f(0.0f, 1.0f, 0.0f);     // Green
      glVertex3f( 1.0f, -1.0f,  1.0f);
      glVertex3f(-1.0f, -1.0f,  1.0f);
      glVertex3f(-1.0f, -1.0f, -1.0f);
      glVertex3f( 1.0f, -1.0f, -1.0f);
 glEnd();
  
 glFlush ();



}
void specialKeys( int key, int x, int y ) {
 
  //  Right arrow - increase rotation by 5 degree
  if (key == GLUT_KEY_RIGHT)
    y += 5;
 
  //  Left arrow - decrease rotation by 5 degree
  else if (key == GLUT_KEY_LEFT)
    y -= 5;
 
  else if (key == GLUT_KEY_UP)
    x += 5;
 
  else if (key == GLUT_KEY_DOWN)
    x -= 5;
 
  //  Request display update
  glutPostRedisplay();
 
}

void reshape (int w, int h)
{
   glViewport (0, 0, (GLsizei) w, (GLsizei) h); 
   glMatrixMode (GL_PROJECTION);
   glLoadIdentity ();
   glFrustum (-1.0, 1.0, -1.0, 1.0, 1.5, 20.0);
   glMatrixMode (GL_MODELVIEW);
}

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
   glutInitWindowSize (1000, 500); 
   glutInitWindowPosition (100, 100);
   glutCreateWindow (argv[0]);
   init ();
   glutDisplayFunc(display);
    glutSpecialFunc(specialKeys); 
   glutReshapeFunc(reshape);
  
   glutMainLoop();
   return 0;
}
