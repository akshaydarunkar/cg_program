import OpenGL 
#OpenGL.ERROR_ON_COPY = True 
from OpenGL.GLUT import *
from OpenGL.GL import *
from OpenGL.GLU import *

x1=0
y1=0
x2=-3
y2=-3
x3=3
y3=-3
list1=[x1,y1,x2,y2,x3,y3]
for i in list1:
 print i

command=[]

def init2D(r,g,b):
    glClearColor(r,g,b,0.0)    
    glMatrixMode (GL_PROJECTION)
    gluOrtho2D (-200.0, 200.0, -200.0, 200.0)


def readFile():
	pclogofile=open('a.txt')
	line=pclogofile.readline()
	cnt=1
	while line:
		command.append(line.strip())
		line=pclogofile.readline()
		cnt+=1
	print command
	cmd=raw_input("enter the command \n ")
	arrrr=cmd.split(' ')
	print arrrr

        if arrrr[0]=='fd' and arrrr[1].isdigit():
		list1[1]=list1[1]+int(arrrr[1])
		list1[3]=list1[3]+int(arrrr[1])
		list1[5]=list1[5]+int(arrrr[1])
	 	
	display()
def display():
    
    glClear(GL_COLOR_BUFFER_BIT)

    glColor3f(1.0, 1.0, 1.0)

    glBegin(GL_LINES)	#
    glVertex2i(-200,0)	# X-axis
    glVertex2i(200,0)	#
    glEnd()		#

    glBegin(GL_LINES)	#
    glVertex2i(0,200)	# Y-axis
    glVertex2i(0,-200)	#
    glEnd()		#
   
    # Tringle
 
    glColor3f(1.0, 0.0, 0.0)
    glBegin(GL_TRIANGLES) 
    glVertex2i(list1[0],list1[1])
    glVertex2i(list1[2],list1[3])
    glVertex2i(list1[4],list1[5])	
    glEnd()  


    glColor3f(1.0, 0.0, 0.0)
    glBegin(GL_TRIANGLES) 
    glVertex2i(list1[0],list1[1]+20)
    glVertex2i(list1[2],list1[3]+20)
    glVertex2i(list1[4],list1[5]+20)	
    glEnd()  

    '''
    glColor3f(1.0, 0.0, 0.0)
    glBegin(GL_LINES)
    glVertex2i(25,0)
    glVertex2i(0,25)
    glEnd()  

    glColor3f(1.0, 0.0, 0.0)
    glBegin(GL_LINES)
    glVertex2i(-25,0)
    glVertex2i(25,0)
    glEnd()   
	'''
    glFlush()
    
glutInit(sys.argv)
glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB)
glutInitWindowSize (800, 600)
glutInitWindowPosition (500, 80)
glutCreateWindow ('Graphics')
init2D(0.0,0.0,0.0)
glutDisplayFunc(readFile)
glutMainLoop()
