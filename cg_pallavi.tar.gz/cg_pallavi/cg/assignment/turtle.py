import OpenGL 
#OpenGL.ERROR_ON_COPY = True 
from OpenGL.GLUT import *
from OpenGL.GL import *
from OpenGL.GLU import *

x1=0
y1=0
x2=-6
y2=-6
x3=6
y3=-6
list1=[x1,y1,x2,y2,x3,y3]

line1=[0,0,0,0]
for i in list1:
 print i

command=[]

def init2D(r,g,b):
    glClearColor(r,g,b,0.0)    
    glMatrixMode (GL_PROJECTION)
    gluOrtho2D (-200.0, 200.0, -200.0, 200.0)


def readFile():
	pclogofile=open('a.txt')
	line=pclogofile.readline()
	cnt=1
	while line:
		command.append(line.strip())
		line=pclogofile.readline()
		cnt+=1
	print command
	ch='yes'
	while(ch=='yes'):
			display()
			cmd=[]
			cmd=raw_input("enter the command \n ")
			arrrr=cmd.split(' ')
			print arrrr
                        print arrrr[0]
 			if str(arrrr[0])=='no':
			 ch='no'
			 break
			else:


				if arrrr[0]=='fd' and arrrr[1].isdigit():
					list1[1]=list1[1]+int(arrrr[1])
					list1[3]=list1[3]+int(arrrr[1])
					list1[5]=list1[5]+int(arrrr[1])
					
					line1[3]=list1[1]
					
					line1.append(list1[0])
					line1.append(list1[1])
				elif arrrr[0]=='bk' and arrrr[1].isdigit():
					list1[1]=list1[1]-int(arrrr[1])
					list1[3]=list1[3]-int(arrrr[1])
					list1[5]=list1[5]-int(arrrr[1])
					
					
					line1.append(list1[0])
					line1.append(list1[1])
					line1[3]=list1[1]
				elif arrrr[0]=='lf' and arrrr[1].isdigit():
					list1[x1]=list1[x1]+int(arrrr[1])
					list1[x2]=list1[x2]+int(arrrr[1])
					list1[x3]=list1[x3]+int(arrrr[1])	
				elif arrrr[0]=='rf' and arrrr[1].isdigit():
					list1[x1]=list1[x1]-int(arrrr[1])
					list1[x2]=list1[x2]-int(arrrr[1])
					list1[x3]=list1[x3]-int(arrrr[1])
		
				ch='yes'
				display()
def display():
    
    glClear(GL_COLOR_BUFFER_BIT)
    glColor3f(1.0, 1.0, 1.0)

    print "I am In dispaly"
   
    glBegin(GL_LINES)	
    for i in range(0,3):
		 print "I am in for loop"
	   	 print line1[i],line1[i-1]
	   	 glVertex2i(line1[i],line1[i-1])	
    glEnd()		
    	    
    # Tringle
 
    glColor3f(0.0, 0.0, 1.0)
    glBegin(GL_TRIANGLES) 
    glVertex2i(list1[0],list1[1])
    glVertex2i(list1[2],list1[3])
    glVertex2i(list1[4],list1[5])	
    glEnd()  


    glFlush()
    
glutInit(sys.argv)
glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB)
glutInitWindowSize (800, 600)
glutInitWindowPosition (500, 80)
glutCreateWindow ('Graphics')
init2D(0.0,0.0,0.0)
glutDisplayFunc(readFile)
glutMainLoop()
