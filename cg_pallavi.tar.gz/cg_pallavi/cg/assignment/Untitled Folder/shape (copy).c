#include <GL/glut.h>
#include <stdlib.h>

GLfloat ctrlpoints[4][3] = {
{ -4.0, 4.0, 0.0}, { 0.0, 0.0, 0.0},
{0.0, 0.0, 0.0}, {-1.0, -4.0, 0.0}};

void init(void)
{
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glShadeModel(GL_FLAT);
	glMap1f(GL_MAP1_VERTEX_3, 0.0, 1.0, 3, 4, &ctrlpoints[0][0]);//one dimentional evaluator 
	glEnable(GL_MAP1_VERTEX_3);//enable or disable server side
}

void display(void)
{
	
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	int i;
	glClear(GL_COLOR_BUFFER_BIT);//clear buffer to preset values//buffer currently enabled for color writing
	glColor3f(0.0, 0.0, 0.0);
	glBegin(GL_LINE_STRIP);
	for (i = 0; i <= 30; i++)
		glEvalCoord1f((GLfloat) i/30.0);
	glEnd();
/* The following code displays the control points as dots. */
	glPointSize(5.0);
	glColor3f(0.0, 0.0, 0.0);
	glBegin(GL_POINTS);
	for (i = 0; i < 4; i++)
		glVertex3fv(&ctrlpoints[i][0]);// 3 floating value
	glEnd();
	glColor3f(0.0, 0.0, 1.0);

	glBegin(GL_LINES);	
        glVertex2i(-10,0);	
        glVertex2i(10,0);
        glEnd();
	glBegin(GL_LINES);	
        glVertex2i(0,10);	
        glVertex2i(0,-10);
        glEnd();
	glFlush();
}

void reshape(int w, int h)
{
	glViewport(0, 0, (GLsizei) w, (GLsizei) h);//x value ,y value,width and highet
	glMatrixMode(GL_PROJECTION);//current matrix
	glLoadIdentity();//replace the current matrix with the identity mtrix
	if (w <= h)
		glOrtho(-6.0, 6.0, -6.0*(GLfloat)h/(GLfloat)w,6.0*(GLfloat)h/(GLfloat)w, -6.0, 6.0);//left,right,bottom,top,NearVal,FarValue
	else
		glOrtho(-6.0*(GLfloat)w/(GLfloat)h,6.0*(GLfloat)w/(GLfloat)h, -6.0, 6.0, -6.0, 6.0);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}
int main(int argc, char** argv)
{
	glutInit(&argc, argv);//initialize the glut library
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);//set the initial display mode//single buffer window//
	glutInitWindowSize (800,500);
	glutInitWindowPosition (100, 100);
	glutCreateWindow (argv[0]);
	init ();
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutMainLoop();
	return 0;
}
